#-*- coding: UTF-8 -*-


print("Olá! Me dê um valor e te mostrarei todos os números do 1 até o inserido!")

valor = int(input("Qual será o valor final?"))

for x in range (1, valor + 1):
    print(x)
