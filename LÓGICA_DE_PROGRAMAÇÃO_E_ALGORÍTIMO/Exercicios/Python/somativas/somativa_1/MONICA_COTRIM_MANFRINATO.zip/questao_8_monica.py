#-*- coding: UTF-8 -*-

def saudacao ():
    print("Me diga o seu nome e te enviarei uma saudação personalizada!")
    nome = input("Qual o seu nome?")
    print(f"Olá {nome} você é muuuito legal! Que bom que você está aqui :) ")

saudacao ()
