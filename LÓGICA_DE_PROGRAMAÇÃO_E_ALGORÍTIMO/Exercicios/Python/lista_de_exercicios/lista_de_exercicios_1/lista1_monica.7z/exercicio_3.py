"""3 - Faça um algoritmo para ler dois números inteiros e escrever o maior."""

print("Me dê dois números inteiros e te direi qual é o maior entre eles")
valor1 = int(input("Qual o primeiro valor?"))
valor2 = int(input("Qual o segundo valor?"))
if valor1 > valor2:
    print("O primeiro valor é maior que o segundo!")
else:
    print("O segundo valor é maior que o primeiro!")
