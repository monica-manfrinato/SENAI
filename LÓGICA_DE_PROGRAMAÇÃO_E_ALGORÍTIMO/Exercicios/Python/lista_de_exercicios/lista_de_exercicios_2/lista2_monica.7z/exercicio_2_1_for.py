"""1 - Faça um programa que mostre na tela todos os números de 1 a 50 e depois essa 
mesma lista invertida (50 a 1) usando laço for."""

#-*- coding: UTF-8 -*-


print(" Vou te mostrar os númerso de 1 até 50 e em seguida apresentar a lista invertida")

for x in range (1,51):
    print(x)
    
for y in range(50, 0, -1):
    print(y)
